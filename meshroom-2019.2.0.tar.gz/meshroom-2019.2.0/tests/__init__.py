import os

from meshroom.core import loadAllNodes

loadAllNodes(os.path.join(os.path.dirname(__file__), "nodes"))
